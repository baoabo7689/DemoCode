
# Quick start game for Cocos Creator

This is the master branch, which is for Cocos Creator.
Note: The `master` branch is only available for the v2.0 or later version of Cocos Creator. Older versions of Creator please [switch to the v1.9 branch](../../tree/v1.9).
